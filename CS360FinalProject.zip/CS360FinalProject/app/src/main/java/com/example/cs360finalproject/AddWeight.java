package com.example.cs360finalproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;


public class AddWeight extends AppCompatActivity {

    String EmailHolder, DescHolder, QtyHolder, UnitHolder;
    TextView UserEmail;
    ImageButton IncreaseQty, DecreaseQty;
    EditText WeightDescValue, WeightQtyValue, WeightUnitValue;
    Button CancelButton, AddWeightButton;
    Boolean EmptyHolder;
    WeightSQL db;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight_activity);

        // Initiate buttons, textViews, and editText variables
        UserEmail = findViewById(R.id.textViewLoggedUser);
        WeightDescValue = findViewById(R.id.editTextWeightDescription);
        WeightUnitValue = findViewById(R.id.editTextWeightUnit);
        IncreaseQty = findViewById(R.id.weightQtyIncrease);
        DecreaseQty = findViewById(R.id.weightQtyDecrease);
        WeightQtyValue = findViewById(R.id.editTextWeightQuantity);
        CancelButton = findViewById(R.id.addCancelButton);
        AddWeightButton = findViewById(R.id.addWeightButton);
        db = new WeightSQL(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receiving user email send by WeightListActivity
        EmailHolder = intent.get().getStringExtra(WeightList.UserEmail);

        // Setting user email on textViewLoggedUser
        UserEmail.setText("User Email: {EmailHolder}");

        // Adding click listener to weightQtyIncrease forgotPasswordButton
        IncreaseQty.setOnClickListener(view -> {
            int input = 0, total;

            String value = WeightQtyValue.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            WeightQtyValue.setText(String.valueOf(total));
        });

        // Adding click listener to WeightQtyDecrease forgotPasswordButton
        DecreaseQty.setOnClickListener(view -> {
            int input, total;

            String qty = WeightQtyValue.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Weight is equal to zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                WeightQtyValue.setText(String.valueOf(total));
            }
        });

        // Adding click listener to addCancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to WeightList after cancel adding weight
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Adding click listener to addWeightButton and pass data to weightListActivity
        AddWeightButton.setOnClickListener(view -> InsertWeightIntoDatabase());
    }

    // Insert weight data into database and send data to WeightListActivity
    public void InsertWeightIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
            String email = EmailHolder;
            String desc = DescHolder;
            String qty = QtyHolder;
            String unit = UnitHolder;

            Weight weight = new Weight(email, desc, qty, unit);
            db.createWeight(weight);

            // Display toast message after insert in table
            Toast.makeText(this,"Weight Added Successfully", Toast.LENGTH_LONG).show();

            // Close AddWeightActivity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            // Display toast message if weight description is empty and focus the field
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking weight description is not empty
    public String CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
        String message = "";
        DescHolder = WeightDescValue.getText().toString().trim();
        UnitHolder = WeightUnitValue.getText().toString().trim();
        QtyHolder = WeightQtyValue.getText().toString().trim();

        if (DescHolder.isEmpty()) {
            WeightDescValue.requestFocus();
            EmptyHolder = true;
            message = "Weight Description is Empty";
        } else if (UnitHolder.isEmpty()){
            WeightUnitValue.requestFocus();
            EmptyHolder = true;
            message = "Weight Unit is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

}
