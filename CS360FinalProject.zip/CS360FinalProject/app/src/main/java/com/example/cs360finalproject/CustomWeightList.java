package com.example.cs360finalproject;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/*
 * This is the custom layout class to show the weight row in the weightScrollView
 */

public class CustomWeightList extends BaseAdapter {

    private final Activity context;
    private PopupWindow popwindow;
    ArrayList<Weight> weights;
    WeightSQL db;

    public CustomWeightList(Activity context, ArrayList<Weight> weights, WeightSQL db) {
        this.context = context;
        this.weights = weights;
        this.db = db;
    }

    public static class ViewHolder {
        TextView textViewWeightId;
        TextView textViewUserEmail;
        TextView textViewWeightDesc;
        TextView textViewWeightQty;
        TextView textViewWeightUnit;
        ImageButton editBtn;
        ImageButton deleteBtn;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.weight_row_template, null, true);

            vh.editBtn = row.findViewById(R.id.editButton);
            vh.textViewWeightId = row.findViewById(R.id.textViewWeightId);
            vh.textViewUserEmail = row.findViewById(R.id.textViewUserEmail);
            vh.textViewWeightDesc = row.findViewById(R.id.textViewWeightDesc);
            vh.textViewWeightQty = row.findViewById(R.id.textViewWeightQty);
            vh.textViewWeightUnit = row.findViewById(R.id.textViewWeightUnit);
            vh.deleteBtn = row.findViewById(R.id.deleteButton);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        vh.textViewWeightId.setText("" + weights.get(position).getId());
        vh.textViewUserEmail.setText(weights.get(position).getUserEmail());
        vh.textViewWeightDesc.setText(weights.get(position).getDesc());
        vh.textViewWeightQty.setText(weights.get(position).getQty());
        vh.textViewWeightUnit.setText(weights.get(position).getUnit());

        // Check is the cell value is zero to change color and send SMS
        String value = vh.textViewWeightQty.getText().toString().trim();
        if (value.equals("0")) {
            // Change background color and text color of weight qty cell if value is zero
            vh.textViewWeightQty.setBackgroundColor(Color.RED);
            vh.textViewWeightQty.setTextColor(Color.WHITE);
            WeightList.SendSMSMessage(context.getApplicationContext());
        } else {
            // Change background color and text color of weight qty cell to default
            vh.textViewWeightQty.setBackgroundColor(Color.parseColor("#E6E6E6"));
            vh.textViewWeightQty.setTextColor(Color.BLACK);
        }

        final int positionPopup = position;

        vh.editBtn.setOnClickListener(view -> editPopup(positionPopup));

        vh.deleteBtn.setOnClickListener(view -> {
            //Integer index = (Integer) view.getTag();
            db.deleteWeight(weights.get(positionPopup));

            //weights.remove(index.intValue());
            weights = (ArrayList<Weight>) db.getAllWeight();
            notifyDataSetChanged();

            Toast.makeText(context, "Weight Deleted", Toast.LENGTH_SHORT).show();

            int weightCount = db.getWeightCount();
            TextView TotalWeights = context.findViewById(R.id.textViewTotalWeightCount);
            TotalWeights.setText(String.valueOf(weightCount));
        });

        return  row;
    }

    public Object getWeight(int position) {
        return position;
    }

    public long getWeightId(int position) {
        return position;
    }

    public int getCount() {
        return weights.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    public void editPopup(final int positionPopup) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.edit_weight_activity, context.findViewById(R.id.popup_element));

        popwindow = new PopupWindow(layout, 800, 1000, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        final EditText editWeightDesc = layout.findViewById(R.id.editTextWeightDescriptionPopup);
        final EditText editWeightQty = layout.findViewById(R.id.editTextWeightQtyPopup);
        final EditText editWeightUnit = layout.findViewById(R.id.editTextWeightUnitPopup);

        editWeightDesc.setText(weights.get(positionPopup).getDesc());
        editWeightQty.setText(weights.get(positionPopup).getQty());
        editWeightUnit.setText(weights.get(positionPopup).getUnit());

        Button save = layout.findViewById(R.id.editSaveButton);
        Button cancel = layout.findViewById(R.id.editCancelButton);

        save.setOnClickListener(view -> {
            String weightDesc = editWeightDesc.getText().toString();
            String weightQty = editWeightQty.getText().toString();
            String weightUnit = editWeightUnit.getText().toString();

            Weight weight = weights.get(positionPopup);
            weight.setDesc(weightDesc);
            weight.setQty(weightQty);
            weight.setUnit(weightUnit);

            db.updateWeight(weight);
            weights = (ArrayList<Weight>) db.getAllWeight();
            notifyDataSetChanged();

            Toast.makeText(context, "Weight Updated", Toast.LENGTH_SHORT).show();

            popwindow.dismiss();
        });

        cancel.setOnClickListener(view -> {
            Toast.makeText(context, "Action Canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }

}
