package com.example.cs360finalproject;

import androidx.appcompat.app.AlertDialog;

public class AD_DeleteWeight {

    public static AlertDialog doubleButton(final WeightList context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete All Weight")
                .setIcon(R.drawable.delete_all_weight)
                .setCancelable(false)
                .setMessage("Are you sure you want to delete all weight history")
                .setPositiveButton("Yes", (dialog, arg1) -> {
                    WeightList.YesDeleteWeight();
                    dialog.cancel();
                })
                .setNegativeButton("No", (dialog, arg1) -> {
                    WeightList.NoDeleteWeight();
                    dialog.cancel();
                });

        // Create the AlertDialog object and return it
        return builder.create();
    }
}
