package com.example.cs360finalproject;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;


public class AD_SMSNotification {

    public static AlertDialog doubleButton(final WeightList context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Allow SMS Alerts?")
                .setIcon(R.drawable.sms_notification)
                .setCancelable(false)
                .setMessage("Allow SMS Akerts")
                .setPositiveButton("Enable", (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Enabled", Toast.LENGTH_LONG).show();
                    WeightList.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton("Disable", (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disabled", Toast.LENGTH_LONG).show();
                    WeightList.DenySendSMS();
                    dialog.cancel();
                });

        // Create the AlertDialog object and return it
        return builder.create();
    }
}
