package com.example.cs360finalproject;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;


public class WeightList extends AppCompatActivity {

    TextView UserName, TotalWeight;
    ImageButton AddWeightButton, SmsButton, DelAllWeightButton;
    ListView WeightListView;
    WeightSQL db;
    static String NameHolder, EmailHolder, PhoneNumHolder;
    AlertDialog AlertDialog = null;
    ArrayList<Weight> weights;
    CustomWeightList customWeightList;
    int weightCount;

    public static final String UserEmail = "";
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsAuthorized = false;
    private static boolean deleteWeight = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_activity);

        // Initiate buttons, textViews, and editText variables
        UserName = findViewById(R.id.textViewUserNameLabel);
        TotalWeight = findViewById(R.id.textViewTotalWeightCount);
        AddWeightButton = findViewById(R.id.addWeightButton);
        SmsButton = findViewById(R.id.smsNotification);
        DelAllWeightButton = findViewById(R.id.deleteAllWeightButton);
        WeightListView = findViewById(R.id.bodyListView);
        db = new WeightSQL(this);

        // Receiving user name and user email send by LoginActivity
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            NameHolder = bundle.getString("user_name");
            EmailHolder = bundle.getString("user_email");
            PhoneNumHolder = bundle.getString("user_phone");
            // Setting user name in textViewUserNameLabel
            UserName.setText("Welcome, {NameHolder.toUpperCase()}!");
        }

        weights = (ArrayList<Weight>) db.getAllWeight();

        weightCount = db.getWeightCount();

        if (weightCount > 0) {
            customWeightList = new CustomWeightList(this, weights, db);
            WeightListView.setAdapter(customWeightList);
        } else {
            Toast.makeText(this, "Database is Empty", Toast.LENGTH_LONG).show();
        }

        TotalWeight.setText(String.valueOf(weightCount));

        // Adding click listener to addWeightButton
        AddWeightButton.setOnClickListener(view -> {
            // Opening new AddWeightActivity using intent on forgotPasswordButton click.
            Intent add = new Intent(this, AddWeight.class);
            add.putExtra(UserEmail, EmailHolder);
            startActivityForResult(add, 1);
        });

        // Adding click listener to smsNotification
        SmsButton.setOnClickListener(view -> {
            // Request sms permission for the device
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.SEND_SMS},
                            USER_PERMISSIONS_REQUEST_SEND_SMS);
                }
            } else {
                Toast.makeText(this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }
            // Open SMS Alert Dialog
            AlertDialog = AD_SMSNotification.doubleButton(this);
            AlertDialog.show();
        });

        DelAllWeightButton.setOnClickListener(view -> {
            weightCount = db.getWeightCount();

            if (weightCount > 0) {
                // Open Delete Alert Dialog
                AlertDialog = AD_DeleteWeight.doubleButton(this);
                AlertDialog.show();

                AlertDialog.setCancelable(true);
                AlertDialog.setOnCancelListener(dialog -> DeleteAllWeight());
            } else {
                Toast.makeText(this, "Database is Empty", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Setting sign out menu weight in AppBar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_weight_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem weight) {
        if (weight.getItemId() == R.id.signOutMenuWeight) {
            // End WeightListActivity on menu weight click.
            db.close();
            super.finish();
            Toast.makeText(this,"Log Out Successful", Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(weight);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                weightCount = db.getWeightCount();
                TotalWeight.setText(String.valueOf(weightCount));

                if(customWeightList == null)	{
                    customWeightList = new CustomWeightList(this, weights, db);
                    WeightListView.setAdapter(customWeightList);
                }

                customWeightList.weights = (ArrayList<Weight>) db.getAllWeight();
                ((BaseAdapter)WeightListView.getAdapter()).notifyDataSetChanged();
            } else {
                Toast.makeText(this, "Action Canceled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Receive and evaluate user response from AlertDialog to delete Weight
    public static void YesDeleteWeight() {
        deleteWeight = true;
    }

    public static void NoDeleteWeight() {
        deleteWeight = false;
    }

    public void DeleteAllWeight() {
        if (deleteWeight) {
            db.deleteAllWeight();
            Toast.makeText(this, "All user weight has been deleted", Toast.LENGTH_SHORT).show();
            TotalWeight.setText("0");

            if (customWeightList == null) {
                customWeightList = new CustomWeightList(this, weights, db);
                WeightListView.setAdapter(customWeightList);
            }

            customWeightList.weights = (ArrayList<Weight>) db.getAllWeight();
            ((BaseAdapter) WeightListView.getAdapter()).notifyDataSetChanged();
        }
    }

    // Receive and evaluate user response from AlertDialog to send SMS
    public static void AllowSendSMS() {
        smsAuthorized = true;
    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    public static void SendSMSMessage(Context context) {
        String phoneNo = PhoneNumHolder;
        String smsMsg = "Congratulations! You've reached your goal weight";

        // Evaluate AlertDialog permission to send SMS and WeightQtyValue value
        if (smsAuthorized) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, smsMsg, null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "App SMS Alert Disable", Toast.LENGTH_LONG).show();
        }
    }
}
